package day11.beans;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.annotation.Autowired;

public class EmployeeAnn {
	
	private String name;
	private int id;
	private int salary;
	private AddressAnn address;
	
	@Autowired
	public EmployeeAnn(String name, int id, int salary, AddressAnn address) {
		super();
		this.name = name;
		this.id = id;
		this.salary = salary;
		this.address = address;
	}
	
	@PostConstruct
	void initializing() {
		System.out.println("Implementation after constructor");
	}

	@PreDestroy
	void destroying() {
		System.out.println("Deleting");
	}

	@Override
	public String toString() {
		return "Employee [name=" + name + ", id=" + id + ", salary=" + salary + ", address=" + address + "]";
	}

	

}
