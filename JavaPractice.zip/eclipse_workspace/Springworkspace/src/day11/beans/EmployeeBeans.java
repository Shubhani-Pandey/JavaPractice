package day11.beans;

public class EmployeeBeans {
	private String empName;
	private int empId;
	
	public void get_details(String empName, int empId) {
		this.empName = empName;
		this.empId = empId;
	}
	
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}

	@Override
	public String toString() {
		return "EmployeeBeans [empName=" + empName + ", empId=" + empId + "]";
	}
	 
	

}
