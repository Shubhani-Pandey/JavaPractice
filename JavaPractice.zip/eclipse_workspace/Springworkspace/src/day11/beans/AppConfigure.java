package day11.beans;

import java.util.Scanner;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AppConfigure {
	 
    @Bean(name="emp1")
	EmployeeAnn employee() {
    	Scanner sc = new Scanner(System.in);
    	String name = sc.nextLine();
    	int id = sc.nextInt();
    	int salary = sc.nextInt();
    	sc.close();
		return new EmployeeAnn(name,id,salary,null);
	}
	
	@Bean
	AddressAnn address() {
		return new AddressAnn("Baker_Street","Haryana",122001);
	}
}
