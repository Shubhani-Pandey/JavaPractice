package day11.beans;

public class AddressAnn {
	
	private String street;
	private String state;
	private int country_id;
	
	public AddressAnn(String street, String state, int country_id) {
		this.street = street;
		this.state = state;
		this.country_id = country_id;
	}
	
	public String getStreet() {
		return street;
	}
	public void setStreet(String street) {
		this.street = street;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public int getCountry_id() {
		return country_id;
	}
	public void setCountry_id(int country_id) {
		this.country_id = country_id;
	}
	
	@Override
	public String toString() {
		return "Address [street=" + street + ", state=" + state + ", country_id=" + country_id + "]";
	}
	
	

}
