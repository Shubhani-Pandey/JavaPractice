package day11Test;

import org.springframework.beans.factory.support.DefaultListableBeanFactory;
import org.springframework.beans.factory.xml.XmlBeanDefinitionReader;
import org.springframework.core.io.ClassPathResource;

import day11.beans.EmployeeBeans;

public class BeanTest {

	public static void main(String[] args) {
		DefaultListableBeanFactory factory = new DefaultListableBeanFactory();
		XmlBeanDefinitionReader reader = new XmlBeanDefinitionReader(factory);
		reader.loadBeanDefinitions(new ClassPathResource("springBeanFactory.xml"));
	    EmployeeBeans obj = (EmployeeBeans) factory.getBean("emp1");
	    obj.get_details("Rohit", 101);
	    System.out.println(obj);

	}

}
