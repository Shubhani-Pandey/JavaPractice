package day11Test;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import day11.beans.AddressAnn;
import day11.beans.EmployeeAnn;

public class AnnotationTest {

	public static void main(String[] args) {
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("springAnnotations.xml");
	    EmployeeAnn obj = (EmployeeAnn) context.getBean("emp1");
	    //AddressAnn obj2 = (AddressAnn) context.getBean("address");
	    System.out.println(obj);
	    //System.out.println(obj2);
	    context.close();

	}

}
