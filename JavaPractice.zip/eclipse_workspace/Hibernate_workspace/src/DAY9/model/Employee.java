package DAY9.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="EmpInfo")
public class Employee {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	//this means primary key that is auto-generated
	private int id;
	
	@Column(name="EmpName")
	private String name;
	
	@Column(name="EmpSalary")
	private int salary;
	
	public Employee(String name, int salary) {
		super();
		this.name = name;
		this.salary = salary;
	}
	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", salary=" + salary + "]";
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}

}
