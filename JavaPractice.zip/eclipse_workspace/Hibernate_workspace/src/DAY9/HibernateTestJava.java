package DAY9;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import DAY9.model.Employee;

public class HibernateTestJava {

	public static void main(String[] args) {
		Configuration cfg = new Configuration().configure();
		SessionFactory sf = cfg.buildSessionFactory();
		Session ss = sf.openSession();
		Transaction t = ss.beginTransaction();
		Employee e1 = new Employee("Tom",70000);  //Transient
		ss.save(e1);
		e1.setSalary(800000);
		t.commit();
		System.out.println("Employee saved successfully");
        ss.close();
        sf.close();
		
		
	}

}
