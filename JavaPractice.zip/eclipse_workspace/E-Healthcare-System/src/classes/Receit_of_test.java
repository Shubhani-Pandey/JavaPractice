package classes;

public class Receit_of_test {
	
	private double amount;

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	@Override
	public String toString() {
		return "Receit_of_test [amount=" + amount + "]";
	}
}
