package assignment3;

public class Employee {
	private int eId;
	private String eName;
	private int eSalary;
	private Department eDept;
	
	Employee(int eId, String eName, int eSalary, Department eDept){
		this.eId = eId;
		this.eName = eName;
		this.eSalary = eSalary;
		this.eDept = eDept;
	}

	public int geteId() {
		return eId;
	}

	public void seteId(int eId) {
		this.eId = eId;
	}

	public String geteName() {
		return eName;
	}

	public void seteName(String eName) {
		this.eName = eName;
	}

	public int geteSalary() {
		return eSalary;
	}

	public void seteSalary(int eSalary) {
		this.eSalary = eSalary;
	}

	public Department geteDept() {
		return eDept;
	}

	public void seteDept(Department eDept) {
		this.eDept = eDept;
	}
	
	@Override
	public String toString() {
		return(geteName());
	}
}
