package assignment3;

import java.util.ArrayList;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Department {
	private int dId;
	private String dname;
	
	Department(int dId, String dName){
		this.dId = dId;
		this.dname= dName;
	}

	public int getdId() {
		return dId;
	}

	public void setdId(int dId) {
		this.dId = dId;
	}

	public String getDname() {
		return dname;
	}

	public void setDname(String dname) {
		this.dname = dname;
	}
	
	

}
