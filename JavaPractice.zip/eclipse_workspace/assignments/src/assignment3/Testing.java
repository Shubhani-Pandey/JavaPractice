package assignment3;

import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.List;
import java.util.Map;
import java.util.ArrayList;

public class Testing {

	@SuppressWarnings({ "rawtypes" })
	public static void main(String[] args) {
		List<Employee> arr = new ArrayList<Employee>();
		arr.add(new Employee(1,"Tom",2000,new Department(100,"PE")));
		arr.add(new Employee(2,"Jerry",30000,new Department(100,"PE")));
		arr.add(new Employee(3,"Ram",4000,new Department(100,"PE")));
		arr.add(new Employee(4,"Shyam",50000,new Department(101,"Finance")));
		arr.add(new Employee(5,"Anonymous",6000,new Department(101,"Finance")));
		
		//Stream stream = arr.stream();
		arr.stream().filter(obj->obj.geteSalary()>5000).forEach(System.out::println);
		
		System.out.println("\n"+arr.stream().distinct().map(Employee::geteName).collect(Collectors.joining(","))+"\n");
		
		Map<Object, Long> l  = arr.stream().collect(Collectors.groupingBy(obj->obj.geteDept().getDname(),Collectors.counting()));
		l.forEach((k,v) -> System.out.println(k+" -> "+v));
		
		System.out.println("\n"+arr.stream().distinct().limit(3).map(Employee::geteSalary).collect(Collectors.toList())+"\n");
		
		//System.out.println("\n"+arr.stream().collect(Collectors.summingInt(Employee::geteSalary)));
		
		Map<Object, List<Employee>> l2  = arr.stream().collect(Collectors.groupingBy(obj->obj.geteDept().getDname()));
		l2.forEach((k,v) -> System.out.println(k+" -> "+v));
	}

}
