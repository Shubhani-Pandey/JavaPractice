package assignment6;

public class Student2 implements Comparable{
    
	private int rollNo;
	private String name;
	
	public Student2(int rollNo, String name) {
		super();
		this.rollNo = rollNo;
		this.name = name;
	}

	public int getRollNo() {
		return rollNo;
	}
	
	public String getName() {
		return name;
	}

	@Override
	public String toString() {
		return "Student2 [rollNo=" + rollNo + ", name=" + name + "]";
	}

	@Override
	public int compareTo(Object o) {
		Student2 s = (Student2)o;
		int diff = name.compareToIgnoreCase(s.name);
		return diff;
	}

}
