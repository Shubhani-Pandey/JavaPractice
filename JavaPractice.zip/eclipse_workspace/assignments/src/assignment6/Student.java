package assignment6;

import java.util.ArrayList;
import java.util.Iterator;

public class Student {
	
	private ArrayList<String> names;
	
	public Student(ArrayList<String> names) {
		super();
		this.names = names;
	}

	public void setNames(String names) {
		this.names.add(names);
	}
	
	public void searchName(String name) {
		System.out.println(names.contains(name));
	}
	
	public void searchName(int index) {
		System.out.println(names.get(index));
	}
	
	public void printNames() {
		Iterator<String> i = names.iterator();
		while(i.hasNext()) {
			System.out.println(i.next());
		}
	}
	
	public void removeName(String stuName) {
		System.out.println(names.remove(stuName));
	}
	
	

}
