package assignment6;

import java.util.ArrayList;

public class ArrayListDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

        ArrayList<String> arr = new ArrayList<String>();
        Student s = new Student(arr);
        
        s.setNames("Ram");
        s.setNames("Shyam");
        s.setNames("Sonu");
        s.setNames("Monu");
        
        
        System.out.println("Searching for name:");
        s.searchName("Ram");
        
        System.out.println("Searching at index:");
        s.searchName(2);
        
        System.out.println("Current names:");
        s.printNames();
        
        System.out.println("Name deleted:");
        s.removeName("Sonu");
        
        System.out.println("Names after deletion:");
        s.printNames();	

	}

}
