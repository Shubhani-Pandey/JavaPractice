package assignment6;

import java.util.ArrayList;
import java.util.Collections;

public class StudentSortDemo {

	@SuppressWarnings("unchecked")
	public static void main(String[] args) {
		ArrayList<Student2> arr = new ArrayList<Student2>();
		arr.add(new Student2(1,"Ram"));
		arr.add(new Student2(2,"Shyam"));
		arr.add(new Student2(3,"Sonu"));
		arr.add(new Student2(4,"Monu"));
		arr.add(new Student2(5,"Ram"));
		
		System.out.println("Unsorted data:");
		System.out.println(arr);
		Collections.sort(arr);
		
		System.out.println("Sorted data:");
		System.out.println(arr);
		
		
		

	}

}
