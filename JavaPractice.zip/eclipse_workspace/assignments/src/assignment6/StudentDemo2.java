package assignment6;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;

public class StudentDemo2 {

	public static void main(String[] args) {
		ArrayList<Student2> arr = new ArrayList<>();
		arr.add(new Student2(1,"Ram"));
		arr.add(new Student2(2,"Shyam"));
		arr.add(new Student2(3,"Sonu"));
		arr.add(new Student2(4,"Monu"));
		arr.add(new Student2(5,"Ram"));
		
		
		Collections.sort(arr,new Compare());
		System.out.println(arr);
	}

}
