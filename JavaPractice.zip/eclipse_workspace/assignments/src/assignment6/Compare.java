package assignment6;

import java.util.Comparator;

public class Compare implements Comparator {

	@Override
	public int compare(Object o1, Object o2) {
		return (((Student2)o1).getName()).compareToIgnoreCase(((Student2)o2).getName());
	}

}
