package assignment5;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Scanner;

public class WriteEmpoyee {

	public static void main(String[] args) throws FileNotFoundException, IOException, ClassNotFoundException {
		// TODO Auto-generated method stub
		int empno = 0,empBasic = 0;
		String empName = null;
		
		Employee e = new Employee(empno,empName,empBasic);
		Scanner sc = new Scanner(System.in);
	    empno = sc.nextInt();
	    e.setEmpno(empno);
		
		sc = new Scanner(System.in);
		empName = sc.nextLine();
		e.setEmpName(empName);
		
		sc = new Scanner(System.in);
		empBasic = sc.nextInt();
		e.setEmpBasic(empBasic);
		
		e = new Employee(empno,empName,empBasic);
		
		File f = new File("Char.txt");
		
//		 ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(f));
//		 oos.writeObject(e);
//		 oos.close();
//        System.out.println("Writing done");
		 
		ObjectInputStream ois = new ObjectInputStream(new FileInputStream(f));
		Employee emp = (Employee)ois.readObject();
		System.out.println(emp);
		ois.close();
			 
		 
		 
		

	}

}
