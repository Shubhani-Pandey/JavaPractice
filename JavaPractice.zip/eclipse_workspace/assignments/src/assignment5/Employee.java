package assignment5;

import java.io.Serializable;

public class Employee implements Serializable{
	private static final long serialVersionUID = 1L;
	private int empno;
	private String empName;
	private int empBasic;
	
	public Employee(int empno, String empName, int empBasic) {
		super();
		this.empno = empno;
		this.empName = empName;
		this.empBasic = empBasic;
	}
	
	

	@Override
	public String toString() {
		return "Employee [empno=" + empno + ", empName=" + empName + ", empBasic=" + empBasic + "]";
	}



	public int getEmpno() {
		return empno;
	}

	public void setEmpno(int empno) {
		this.empno = empno;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public int getEmpBasic() {
		return empBasic;
	}

	public void setEmpBasic(int empBasic) {
		this.empBasic = empBasic;
	}
	
	
	

}
