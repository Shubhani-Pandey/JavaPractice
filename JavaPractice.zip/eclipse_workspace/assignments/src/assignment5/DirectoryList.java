package assignment5;

import java.io.File;
import java.util.Scanner;

public class DirectoryList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		String path = sc.nextLine();
		int a = 0;
		File f  =new File(path);
		
	    try {
			boolean res = f.isDirectory();
			if(res) {
				String s[] = f.list();
				while(a < s.length)
				{	System.out.println(s[a]);
					a++;
				}
			}
	    }
	    catch(Exception e) {
	    	System.out.println("Directory doesn't exist"+e);
	    }
        sc.close();
	}

}
