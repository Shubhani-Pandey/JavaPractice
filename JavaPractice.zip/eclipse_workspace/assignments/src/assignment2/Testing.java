package assignment2;

public class Testing {

	public static void main(String[] args) {
		EngineeringBook eb1,eb2;
		eb1 = new EngineeringBook("ABC",200,2,"JKR","jkr@gmail.com",'f',"Engineering");
		eb2 = new EngineeringBook("ABC2",400,4,"JKR2","jkr2@gmail.com",'f',"Engineering");
		
		System.out.println(eb1);
		System.out.println(eb2);

	}

}
