package assignment2;

public class EngineeringBook extends Book{
	
	private String category;
	
	public EngineeringBook(String name, double price, int qty, String authName, String gmail, char gender, String category ){
		super(name,price,qty, new Author(authName,gmail,gender));
		this.category = category;
	}
	
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	
    
}
