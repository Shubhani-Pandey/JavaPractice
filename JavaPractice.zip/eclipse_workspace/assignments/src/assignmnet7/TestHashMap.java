package assignmnet7;

import java.util.HashMap;

public class TestHashMap {

	public static void main(String[] args) {
		HashMap<String,String> h = new HashMap<>();
		Employee<Object> e = new Employee<Object>(h);
		
		e.setEmpNames("101","Raju");
		e.setEmpNames("102","Mukesh");
		e.setEmpNames("103","Suresh");
		e.setEmpNames("101","Rajni");
		
		System.out.println("Printing values->");
		e.printNames();
		
		System.out.println("Printing using keyset->");
		e.printNameKeySet();
		
		System.out.println("Size of HashMap->");
		e.printSize();
		
		System.out.println("Removal of one element->");
		e.remove("101");
		
		System.out.println("Size after removal->");
		e.printSize();

	}

}
