package assignmnet7;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

public class Employee<E> {
	private HashMap<String, String> empNames;

	
	public Employee(HashMap<String, String> empNames) {
		super();
		this.empNames = empNames;
	}

	public HashMap<String, String> getEmpNames() {
		return empNames;
	}

	public void setEmpNames(String key, String value) {
		this.empNames.put(key, value);
	}
	
	public void printNameKeySet() {
		Set<String> s = empNames.keySet();
		Iterator<E> it = (Iterator<E>) s.iterator();
		
		while(it.hasNext()) {
			Object obj = it.next();
			System.out.println(empNames.get(obj));
		}
	}
	
	public void printNames() {
		empNames.forEach((key,value) -> System.out.println(value));	
	}
	
	public void printSize() {
		System.out.println(empNames.size());
	}
	
	public void remove(String key) {
		if(empNames.containsKey(key)) { 
			empNames.remove(key);
			System.out.println("Key value pair removed");
		}
		else
			System.out.println("key not present");
	}
	
	

}
