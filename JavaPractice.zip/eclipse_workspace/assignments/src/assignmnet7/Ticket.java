package assignmnet7;

import assignment6.Student2;

public class Ticket  {
	private int price;
	private String source;
	private String destination;
	private int ticketId;
	
	public Ticket(int price, String source, String destination, int ticketId) {
		super();
		this.price = price;
		this.source = source;
		this.destination = destination;
		this.ticketId = ticketId;
	}

	@Override
	public String toString() {
		return "Ticket [price=" + price + ", source=" + source + ", destination=" + destination + ", ticketId="
				+ ticketId + "]";
	}
	

	public void setPrice(int price) {
		this.price = price;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public void setTicketId(int ticketId) {
		this.ticketId = ticketId;
	}

	public int getPrice() {
		return price;
	}

	public String getSource() {
		return source;
	}

	public String getDestination() {
		return destination;
	}

	public int getTicketId() {
		return ticketId;
	}

	public int compareTo(Object o) {
		Ticket t = (Ticket)o;
		return ticketId-t.ticketId;
	}
	
	public boolean equals(Object obj) {
		Ticket t = (Ticket)obj;
		if(ticketId == t.ticketId)
			return true;
		else
			return false;
	}
	
	public int hashCode() {
		return ticketId;
	}
	
	
	

}
