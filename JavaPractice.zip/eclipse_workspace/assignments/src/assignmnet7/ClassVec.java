package assignmnet7;

import java.util.Enumeration;
import java.util.Vector;
class Student{
    private String name;
	public Student(String name) {
		this.name = name;
	}
	@Override
	public String toString() {
		return "Student [name=" + name + "]";
	}

}

class Teacher{
	private String name;
	public Teacher(String name) {
		this.name = name;
	}
	@Override
	public String toString() {
		return "Teacher [name=" + name + "]";
	}
}

class HOD{	
	private String name;
	public HOD(String name) {
		this.name = name;
	}
	@Override
	public String toString() {
		return "HOD [name=" + name + "]";
	}
}

/*
 * class GenericClass<T>{ Vector<T> v ; void setVal(T c) { this.v.add(c); }
 * 
 * void display() { System.out.println(this.v.toString()); }
 * 
 * @Override public String toString() { return "GenericClass [v=" + v + "]"; } }
 */

public class ClassVec {
	
	public static void main(String[] args) {
		
		Vector v = new Vector();
		
		v.add(new Student("Meena"));
		v.add(new Teacher("Sheena"));
		v.add(new HOD("Reena"));
		
		Enumeration en = v.elements();
		
		while(en.hasMoreElements()) {
			Object obj = en.nextElement();
			System.out.println(obj + "Instance of "+ obj.getClass().getSimpleName());
		}
		
		/*
		 * GenericClass<Student> vs= new GenericClass<>(); vs.setVal(new
		 * Student("meena"));
		 * 
		 * GenericClass<Teacher> vt= new GenericClass<>(); vt.setVal(new
		 * Teacher("reena"));
		 * 
		 * GenericClass<HOD> vh= new GenericClass<>(); vh.setVal(new HOD("sheena"));
		 * 
		 * List arr =new List(); arr.add(vs.toString()); arr.add(vt.toString());
		 * arr.add(vh.toString());
		 * 
		 * System.out.println(arr);
		 */
		
	}

}
