package assignmnet7;

import java.util.HashSet;

public class CallHashSet {

	public static void main(String[] args) {
		HashSet<String> hs = new HashSet<String>();
		
		TestHashSet ths = new TestHashSet(hs);
		
		ths.setHs("Ramu");
		ths.setHs("Gopu");
		ths.setHs("Ram");
		ths.setHs("Shyam");
		
		System.out.println(ths);
		ths.removal("Ram");
		System.out.println(ths);
	}

}
