package assignmnet7;

import java.util.Iterator;
import java.util.LinkedHashSet;

public class TicketDemo {

	public static void main(String[] args) {
		LinkedHashSet<Ticket> lhs = new LinkedHashSet<>();
		lhs.add(new Ticket(200,"a","b",1));
		lhs.add(new Ticket(300,"b","c",2));
		lhs.add(new Ticket(200,"c","d",1));
		
		System.out.println(lhs);
		
		Iterator<Ticket> it = lhs.iterator();
		while(it.hasNext()) {
			System.out.println(it.next());
		}

	}

}
