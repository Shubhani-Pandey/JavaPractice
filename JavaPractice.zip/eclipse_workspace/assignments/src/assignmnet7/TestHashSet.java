package assignmnet7;

import java.util.HashSet;

public class TestHashSet {
	private HashSet<String> hs;

	public TestHashSet(HashSet<String> hs) {
		super();
		this.hs = hs;
	}

	public HashSet<String> getHs() {
		return hs;
	}

	public void setHs(String s) {
		this.hs.add(s);
	}
	
	public void removal(String s) {
		if(hs.contains(s)) {
			hs.remove(s);
			System.out.println("String removed");
		}
		else
			System.out.println("String not found");
	}

	@Override
	public String toString() {
		return "TestHashSet [hs=" + hs + "]";
	}

}
