package assignment8;

import java.time.LocalDateTime;

class MyCurrentDate implements Runnable{
    
	private LocalDateTime now;

	@Override
	public void run() {
		for(int i=0;i<10;i++) {
			System.out.println("Printing times..."+ i+ " " +java.time.LocalDate.now() + " "+ java.time.LocalTime.now());
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		
		
	}
	
}
public class MyMain {

	public static void main(String[] args) {
		Thread th1 = new Thread(new MyCurrentDate());
		Thread th2 = new Thread(new MyCurrentDate());
		Thread th3 = new Thread(new MyCurrentDate());
		th1.start();
		th2.start();
		th3.start();

	}

}
