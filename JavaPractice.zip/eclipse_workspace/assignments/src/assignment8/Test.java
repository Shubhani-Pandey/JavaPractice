package assignment8;

//import assignment8.Printer.Counter.Storage;

class Printer implements Runnable{
	Storage s;

	Printer(Storage s){
		this.s =s;
	}
	
	@Override
	public void run() {
		synchronized(s) {
			for(int i=s.getI();i<10;i++) {
				System.out.println("Printer printing value "+i);
				s.notify();
				
				try {
					s.wait();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}
	}
}

class Counter implements Runnable{
	Storage s;

	Counter(Storage s){
		this.s =s;
	}

	@Override
	public void run() {
		synchronized(s) {
			for(int i=s.getI();i<10;i++) {
				s.setI(i);
				System.out.println("Counter incremented value..........."+i);
				s.notify();
			
				try {
					s.wait();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}	
}
class Storage{
	private int i=0;

	public int getI() {
		return i;
	}

	public void setI(int i) {
		this.i = i;
	}
}

public class Test {

	public static void main(String[] args) {
		Storage s = new Storage();
		Thread th1 = new Thread(new Counter(s));
		Thread th2 = new Thread(new Printer(s));
		th2.start();
		th1.start();
	}
}
