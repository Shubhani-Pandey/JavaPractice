package assignment1plus2;

public class Book {
		private int bookNo;
		private String title;
		private String author;
		private float price;
		private static int bookCount;
		
		static {
			bookCount = 0;
		}
		
		public static int getBookCount() {
			bookCount+= 1;
			return bookCount;
		}
		
		Book(int No, String name, String writer, float cost){
			this.bookNo = No;
			this.author = writer;
			
			
			if(name.length()>=4)
				this.title = name;
			else
				System.err.println("Title length is too samll!!!");
				
			if(cost>=1 && cost <=5000)
				this.price = cost;
			else
				System.err.println("Price doesn't meet the criteria!!!");
			
		}
		
		public int getBookNo() {
			return bookNo;
		}
		public void setBookNo(int bookNo) {
			this.bookNo = bookNo;
		}
		public String getTitle() {
			return title;
		}
		public void setTitle(String title) {
			this.title = title;
		}
		public String getAuthor() {
			return author;
		}
		public void setAuthor(String author) {
			this.author = author;
		}
		public float getPrice() {
			return price;
		}
		public void setPrice(float price) {
			this.price = price;
		}
		
		@Override
	    public String toString() { 
	    	System.out.println("....BOOK FOUND....");
	    	System.out.println("Book_No.\tTitle\tAuthor\tPrice");
	    	return (getBookNo()+"\t\t"+getTitle()+"\t"+getAuthor()+"\t"+getPrice());
	    }
		

}
