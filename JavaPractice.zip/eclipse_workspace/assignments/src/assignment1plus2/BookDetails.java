package assignment1plus2;
import java.util.Scanner;

public class BookDetails {
	
	public static void main( String[] args) {
	
	int bookNo=0,bookPrice=1,bookNum;
	String bookTitle="null",bookAuthor="null";
	
	Book data = new Book(bookNo,bookTitle,bookAuthor,bookPrice);
	
	Book[] books;
	books = new Book[3];
	Scanner sc = new Scanner(System.in);
	
	//.....PART1.....//
	for(int i=0;i<=2;i++) {
		books[i] = data;
		bookNo = sc.nextInt();
		data.setBookNo(bookNo);
		
		sc = new Scanner(System.in);
		bookTitle = sc.nextLine();
		data.setTitle(bookTitle);
		
		sc = new Scanner(System.in);
		bookAuthor = sc.nextLine();
		data.setAuthor(bookAuthor);
		
		sc = new Scanner(System.in);
		bookPrice = sc.nextInt();
		data.setPrice(bookPrice);
		
		
		books[i] = new Book(bookNo,bookTitle,bookAuthor,bookPrice);
	}
	
	System.out.println("Book_No.\tTitle\tAuthor\tPrice\tBookCount");
	for(int i=0;i<=2;i++) {
		System.out.println(books[i].getBookNo()+"\t\t"+books[i].getTitle()+"\t"+books[i].getAuthor()+"\t"+books[i].getPrice()+"\t"+ Book.getBookCount());
	}
    
	//....PART2 and PART3.....//
	System.out.println("Enter the book number you want to search:");
	sc = new Scanner(System.in);
	bookNum = sc.nextInt();
	
	for(int i=0;i<=2;i++) {
		if(books[i].getBookNo() == bookNum) {
			System.out.println(books[i]);
		}
		else {
			System.err.println("...BOOK YOU SEARCHED FOR COULDN'T BE FOUND....");
		}
	}
	
	sc.close();
	
}
}
