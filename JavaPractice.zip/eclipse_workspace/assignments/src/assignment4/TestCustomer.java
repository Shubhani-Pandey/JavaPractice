package assignment4;
import java.util.Scanner;

public class TestCustomer {

	public static void main(String[] args) {
		
		@SuppressWarnings("resource")
		Scanner sc = new Scanner(System.in);
		String custNo = sc.nextLine();
		
		sc = new Scanner(System.in);
		String custName = sc.nextLine();
		
		sc = new Scanner(System.in);
		String category = sc.nextLine();
		
		Customer cust = new Customer(custNo,custName,category);
		System.out.println(cust.getCustNo()+ "\t" +cust.getCustName()+ "\t" +cust.getCategory());

	}

}
