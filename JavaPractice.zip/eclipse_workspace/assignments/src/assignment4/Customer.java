package assignment4;

@SuppressWarnings("serial")
class InvalidCustomerException extends RuntimeException{
    
	private String mssg;
	
	InvalidCustomerException(String s)
	{
		if(s.equals("custno")) 
			mssg = "custno should start with C or c";
		else if(s.equals("custname"))
			mssg = "custname should be atleast 4 in length";
		else if(s.equals("category"))
			mssg = "category should be either Gold Silver or Platinum";
	}
	 @Override public String toString() { 
		 return "InvalidCustomerException : Value other then ideal value given -> "+ mssg; }
	
}

public class Customer {
	private String custNo;
	private String custName;
	private String category;
	
	public Customer(String custNo, String custName, String category) {
		super();
		if(custNo.charAt(0)=='C' || custNo.charAt(0)=='c' )
			this.custNo = custNo;
		else
			throw new InvalidCustomerException("custno");
		
		if(custName.length()>=4)
			this.custName = custName;
		else
			throw new InvalidCustomerException("custname");
		
		if(category.equals("Platinum") || category.equals("Gold") || category.equals("Silver") )
			this.category = category;
		else
			throw new InvalidCustomerException("category");
		
	}

	public String getCustNo() {
		return custNo;
	}

	public String getCustName() {
		return custName;
	}

	public String getCategory() {
		return category;
	}
}
