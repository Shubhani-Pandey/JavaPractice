package Practice;

public class Gfg2 
{ 
    public static void main(String[] args) 
    { 
        Integer a = 128, b = 128; 
        System.out.println(a == b); 
  
        Integer c = 100, d = 100; 
        System.out.println(c == d); 
    } 
} 
