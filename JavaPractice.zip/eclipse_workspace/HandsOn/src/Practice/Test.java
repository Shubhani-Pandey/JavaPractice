package Practice;

class A{
	
	public A(int n) {
		System.out.println("constructor of A-> "+n);
	}
	
	public void get() {
		System.out.println("class a");
	}
}

public class Test extends A {
    
	public void get() {
		System.out.println("class test");
	}
	
	public Test(int n) {
		super(n);
		System.out.println("constructor of A-> "+n);
	}
	
	public static void main(String[] args) {
		A t = new Test(4);
		t.get();
      
	}

}
