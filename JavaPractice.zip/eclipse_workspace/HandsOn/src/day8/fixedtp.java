package day8;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

class thread1 implements Runnable{

	@Override
	public void run() {
		System.out.println("thread running....."+Thread.currentThread().getName());
	}
	
}
public class fixedtp {

	public static void main(String[] args) {
		//to get number of cores...since number of threads = number of cores
		int nThreads = Runtime.getRuntime().availableProcessors();
		ExecutorService service = Executors.newFixedThreadPool(nThreads);
		for(int i=0;i<20;i++)
			service.execute(new thread1());
	}

}
