package day8;
class storage{
	
	private boolean empty = true;

	public boolean isEmpty() {
		return empty;
	}

	public void setEmpty(boolean empty) {
		this.empty = empty;
	}
}

class Producer implements Runnable{
    storage s;   
	Producer(storage s){
		this.s = s;
	}
	
	@Override
	public void run() {
		synchronized(s) {
		for(int i=1;i<=5;i++) {
			if(!s.isEmpty())
				try {
					s.wait();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			System.out.println("Producer is producing...."+i);
			s.setEmpty(false);
			s.notify();
		}
		}
	}
}

class Customer implements Runnable{
	storage s;
	Customer(storage s){
		this.s = s;
	}
	
	@Override
	public void run() {
		synchronized(s) {	
		for(int i=1;i<=5;i++) {
			if(s.isEmpty())
				try {
					s.wait();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			System.out.println("Consumer is consuming...."+i);
			s.setEmpty(true);
			s.notify();
		}
		}
	}
}

public class InterThreadComm {

	public static void main(String[] args) {
		storage s = new storage();
		Thread th1 = new Thread(new Producer(s));
		Thread th2 = new Thread(new Customer(s));
		th1.start();
		th2.start();
		

	}

}
