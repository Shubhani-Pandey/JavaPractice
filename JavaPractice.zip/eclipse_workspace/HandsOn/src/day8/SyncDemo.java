package day8;

class Printer{
	//synchronized method
	synchronized void printing() {
		System.out.println("Strating printing...."+Thread.currentThread().getName());
//		try {
//			Thread.sleep(2000);
//		} catch (InterruptedException e) {
//			e.printStackTrace();
//		}
		
		System.out.println("Ending printing...."+Thread.currentThread().getName());
	}
	
}
class Machine implements Runnable{
	Printer p;
	
	public Machine(Printer p) {
		this.p = p;
	}

	@Override
	public void run() {
		//synchronized block
		//synchronized(p){
			p.printing();
			
		//}
	}
	
}
public class SyncDemo {

	public static void main(String[] args) {
		Printer p = new Printer();
		Thread th1 = new Thread(new Machine(p));
		Thread th2 = new Thread(new Machine(p));
		Thread th3 = new Thread(new Machine(p));
		th1.start();
		th2.start();
		th3.start();

	}

}
