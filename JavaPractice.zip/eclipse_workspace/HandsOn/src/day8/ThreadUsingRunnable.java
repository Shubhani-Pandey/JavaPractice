package day8;

class myThread2 implements Runnable{
	public void  run() {
		for(int i=0;i<5;i++) {
			System.out.println("hi "+i + Thread.currentThread().getName());
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			System.out.println("bye "+i + Thread.currentThread().getName());
		}
	}
	
}

public class ThreadUsingRunnable {

	public static void main(String[] args) {
		System.out.println(Thread.activeCount());
		myThread2 mt1 = new myThread2();
		myThread2 mt2 = new myThread2();
		//System.out.println(mt1.getState());
		System.out.println(Thread.activeCount());
		Thread th1 = new Thread(mt1);
		Thread th2 = new Thread(mt2);
		//here we are passing different objects of class mythreda2
		//to make it synchronous pass same object in Thread constructor
		
		th1.start();
		th2.start();
		/*
		 * try { mt1.join(); } catch (InterruptedException e) { e.printStackTrace(); }
		 */
		System.out.println(th1.getState());

	}

}

