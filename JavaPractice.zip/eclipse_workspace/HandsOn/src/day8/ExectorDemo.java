package day8;

public class ExectorDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
