package day8;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

class thread3 implements Runnable{

	@Override
	public void run() {
		System.out.println("thread running....."+Thread.currentThread().getName());
	}
	
}

public class scheduledpoolDemo {

	public static void main(String[] args) {
		ScheduledExecutorService service = Executors.newScheduledThreadPool(5);
		service.schedule(new thread3(), 2, TimeUnit.SECONDS);
		service.scheduleAtFixedRate(new thread3(), 2,5, TimeUnit.SECONDS);
		service.scheduleWithFixedDelay(new thread3(), 2,5, TimeUnit.SECONDS);

	}

}
