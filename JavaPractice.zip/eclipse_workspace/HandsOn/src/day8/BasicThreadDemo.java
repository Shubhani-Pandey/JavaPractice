package day8;

class myThread extends Thread{
	public synchronized void  run() {
		for(int i=0;i<5;i++) {
			System.out.println("hi "+i + Thread.currentThread().getName());
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			System.out.println("bye "+i + Thread.currentThread().getName());
		}
	}
	
}

public class BasicThreadDemo {

	public static void main(String[] args) {
		System.out.println(Thread.activeCount());
		myThread mt1 = new myThread();
		myThread mt2 = new myThread();
		//System.out.println(mt1.getState());
		System.out.println(Thread.activeCount());
		mt1.start();
		mt2.start();
        //here we are creating two different objects for two different threads
		//to see synchronous output we need to create two threads with same object.
		/*
		 * try { mt1.join(); } catch (InterruptedException e) { e.printStackTrace(); }
		 */
		System.out.println(mt1.getState());

	}

}
