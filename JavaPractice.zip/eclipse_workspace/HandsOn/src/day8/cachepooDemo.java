package day8;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

class thread2 implements Runnable{

	@Override
	public void run() {
		System.out.println("thread running....."+Thread.currentThread().getName());
	}
	
}

public class cachepooDemo {

	public static void main(String[] args) {
		ExecutorService service = Executors.newCachedThreadPool();
		for(int i=0;i<20;i++)
			service.execute(new thread2());

	}

}
