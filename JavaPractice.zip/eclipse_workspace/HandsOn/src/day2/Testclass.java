package day2;

public class Testclass {

	public static void main(String[] args) {
		Manager mn = new Manager(1,"abc",200000,"baker street","ggn","haryana",122001,"PE");
		System.out.println(mn);
		

	}

}
