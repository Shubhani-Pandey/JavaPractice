package day2;

public class Manager extends Employee {
    private String department;
    
	public Manager(int id, String name, double salary, String address, String city, String state, int zipcode, String department){
		super(id,name,salary,new Address(address,city,state,zipcode));
		this.department = department;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

    
}
