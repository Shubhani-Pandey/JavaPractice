package day5;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;

@SuppressWarnings("unused")
public class CharStream {

	public static void main(String[] args) throws IOException {
		File f = new File("Char.txt");
		/*
		 * FileWriter fw = new FileWriter(f); 
		 * String str="Hello world"; 
		 * fw.write(str);
		 * fw.close();
		 */
		
		BufferedReader br = new BufferedReader(new FileReader(f));
		System.out.println("content from file-> "+ br.readLine());
		br.close();
	}

}
