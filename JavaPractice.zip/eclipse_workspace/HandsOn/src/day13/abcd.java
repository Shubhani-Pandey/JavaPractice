package day13;

public class abcd {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        double x =500.0;
        double y = x-(10/100)*x;
        System.out.println(y);
	}

}
