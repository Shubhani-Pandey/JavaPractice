import java.util.*;

class Account{
	int accNo;
	String accName;
	String accType;
	double accBal;
	
	Account(int accNo, String accName, String accType, double accBal, boolean companyTransport) {
		this.accNo = accNo;
		this.accName = accName;
		this.accType = accType;
		this.accBal = accBal;
		
	}
	
}
public class MyMain {
	public static void main(String[] args) {
		Account[] arr=new Account[4];
		Scanner sc= new Scanner(System.in);
		for(int i=0;i<4;i++) {
			int id = sc.nextInt();
			String eaccName = sc.nextLine();
			String eaccType = sc.nextLine();
			double rate = sc.nextDouble();
			boolean transport = sc.nextBoolean();
			arr[i] = new Account(id,eaccName,eaccType,rate,transport);
			
			sc.nextLine();
			String accTypeType=sc.nextLine();
			
			int count=findCountOfAccountsUsingCompTransport(arr,accTypeType);
			if(count==0)
				System.out.println("No such Account found with given account name");
			else
				System.out.println(count);
		}
		
		Account emp=  findAccountwithSecondHighestaccBal(arr);
		if(emp==null)
			System.out.println("No Account sues company transport");
		else {
		    System.out.println(emp.accName);
		}

	}

public static int countAccounts(Account[] obj, String s) {
	int count=0;
	for(int i=0;i<obj.length;i++)
	{
		if(obj[i].accName.equals(s))
			count++;
	}
	
	if(count==0)
		return 0;
	else
		return count;
}

public static Account searchAccounts(Account[] obj, Double d) {
	ArrayList<Account> list = new ArrayList<>();
	for(int i=0;i<obj.length;i++)
	{
		if(obj[i].companyTransport)
			list.add(obj[i]);
	}
	
	if(list.size()<2)
		return null;
	
	Collections.sort(list,(a,b)-> Double.compare(a.accBal , b.accBal));
	return list.get(list.size()-2);
}
}
