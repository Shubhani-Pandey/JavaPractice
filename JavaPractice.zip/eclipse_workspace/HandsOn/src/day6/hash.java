package day6;

/*
 * class Student() { private int id; private String name;
 * 
 * public Student(int id, String name) { super(); this.id = id; this.name =
 * name; }
 * 
 * public int getId() { return id; }
 * 
 * public void setId(int id) { this.id = id; }
 * 
 * public String getName() { return name; }
 * 
 * public void setName(String name) { this.name = name; }
 * 
 * 
 * }
 * 
 * public class hash { public static void main(String[] args) { LinkedHashSet h
 * =new LinkedHashSet();
 * 
 * h.add("101","Shubhani"); h.add("102","Sonu"); h.add("103","Monu");
 * h.add("102","Somu"); } }
 */