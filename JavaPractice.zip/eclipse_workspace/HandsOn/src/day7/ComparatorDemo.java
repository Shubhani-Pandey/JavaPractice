package day7;

/*class Employee()
public class ComparatorDemo {
	
	private int id;
	private String name;
	private int salary;

	public ComparatorDemo(int id, String name, int salary) {
		super();
		this.id = id;
		this.name = name;
		this.salary = salary;
	}

	@Override
	public String toString() {
		return "ComparatorDemo [id=" + id + ", name=" + name + ", salary=" + salary + "]";
	}*/

	/*public static void main(String[] args) {
		TreeSet ts = new TreeSet();
		ts.add(new Empoyee(101"Rohit",7000));

	}

}*/
