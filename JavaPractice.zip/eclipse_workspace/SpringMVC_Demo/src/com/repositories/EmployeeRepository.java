package com.repositories;

import java.util.ArrayList;
import java.util.List;

import com.model.Employee;

public class EmployeeRepository {
	
	List<Employee> emps=null;
	EmployeeRepository(){
		emps=new ArrayList<Employee>();
		emps.add(new Employee(101,"Rohit",80000));
		emps.add(new Employee(102,"Ronit",70000));
		emps.add(new Employee(103,"Mohit",87000));
		emps.add(new Employee(104,"Ram",80040));
		emps.add(new Employee(105,"Raman",82300));
	}
	public List<Employee> getAllEmployees(){
		return emps;
	}
	
	public Employee getEmp(int id){
		if(emps.contains(id)) {
			for(Employee temp:emps) {
				if(temp.getId(id)==id)
					return temp;
			}
			return null;
		}
		else
			return null;
	}
	
	public String create(Employee emp) {
		emps.add(emp);
		return "Employee added successfully";
	}
	
	public String updateEmp(Employee emp) {
			for(Employee temp : emps) {
				if(temp.getId(emps.indexOf(temp))==emp.getId(emps.indexOf(emp))) {
					emps.set(emps.indexOf(temp), emp);
					break;
				}
			}
			return "employee deleted successfully";	
		}		
	
	public String deleteEmp(int id){
		for(Employee temp:emps) {
			if(temp.getId(id)==id) {
				System.out.println(emps.remove(emps.indexOf(id))); 
		        break;
			}	
	     }
		return "employee deleted successfully";	
	}
}
