package com.controllers;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.model.Employee;
import com.repositories.EmployeeRepository;

@RestControllerAdvice
@RequestMapping("restservice")
public class MyRestController {
	EmployeeRepository empResp;
	
	@RequestMapping(value="/employees",method=RequestMethod.GET)
	public String getAllEmployees() { //.../restservice/employees
		return "All employees";	
	}
	
	@RequestMapping(value="/employees/{id}",method=RequestMethod.GET)
	public Employee getEmp(@PathVariable int id) {
		return empResp.getEmp(id);
	}
	
	@RequestMapping(value="/employees/add",method=RequestMethod.POST)
	public String createEmp(@RequestParam("id") int i,@RequestParam("name") String name,@RequestParam("salary") double salary) {
		Employee emp= new Employee(i,name,salary);
		return empResp.create(emp);
	}
	
	@RequestMapping(value="/employees/delete/{id}",method=RequestMethod.DELETE)
	public String deleteEmp(@PathVariable int id) {
		return empResp.deleteEmp(id);
	}
	
	
}