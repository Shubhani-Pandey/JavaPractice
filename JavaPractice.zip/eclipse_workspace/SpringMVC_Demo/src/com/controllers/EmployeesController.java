package com.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

//if controller annotatin isn't used we would have to implement the abstract class controller
//@Controller
//@RequestMapping("/abc")
//public class EmployeesController {

//	@RequestMapping("/welcome")
//	public ModelAndView welcome() {
//		ModelAndView mv= new ModelAndView("index");  //view name
//		mv.addObject("name","Shubhani Pandey");     //model-object
//		return mv; 
//	}
//	
//	@RequestMapping("/login")
//	public ModelAndView login() {
//	ModelAndView mv= new ModelAndView("login");  //view name
//	return mv;
//	}
//	
//	@RequestMapping("/fetchEmp/{id}")
//	public ModelAndView fetchingEmp(@PathVariable int id) {
//	ModelAndView mv= new ModelAndView("employeeData");
//	mv.addObject("id", id);
//	mv.addObject("ename","Rohit");
//	return mv;
//	}
//	
//	@RequestMapping("/auth")
//	public ModelAndView authentication(@RequestParam String user,@RequestParam String pwd) {
//	ModelAndView mv= new ModelAndView("auth");
//	boolean auth=false;
//	if(user.equals("Shubhani") && pwd.equals("1234"))
//		auth=true;
//	
//	if(auth==true)
//		return mv;
//	else
//		return null;
//	}

//}
